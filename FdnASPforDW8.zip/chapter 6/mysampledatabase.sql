/*
Script by: Rob Turnbull
Purpose  : To generate database objects in the SQL Server database and to insert data into the tables.
         : Data is inserted into tblAuthors, tblQuotes and tblCategories
         : Permissions are assigned to the Public Role on all objects

Notes    : Open this script in Query Analyzer and run it against your own database to create the objects






TABLES
*/


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_tblCustomer_Order_Details_tblCustomer_Orders]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[tblCustomer_Order_Details] DROP CONSTRAINT FK_tblCustomer_Order_Details_tblCustomer_Orders
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_tblCustomer_Orders_tblCustomers]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[tblCustomer_Orders] DROP CONSTRAINT FK_tblCustomer_Orders_tblCustomers
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblAdmin]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblAdmin]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblAuthors]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblAuthors]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblCategories]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblCategories]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblCustomer_Order_Details]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblCustomer_Order_Details]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblCustomer_Orders]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblCustomer_Orders]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblCustomers]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblCustomers]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblQuotes]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblQuotes]
GO

CREATE TABLE [dbo].[tblAdmin] (
	[ID] [int] IDENTITY (1, 1) NOT NULL ,
	[Username] [varchar] (50) COLLATE Latin1_General_CI_AS NULL ,
	[Password] [varchar] (50) COLLATE Latin1_General_CI_AS NULL ,
	[AccessLevel] [varchar] (50) COLLATE Latin1_General_CI_AS NULL ,
	[Included] [bit] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblAuthors] (
	[AuthorID] [int] IDENTITY (1, 1) NOT NULL ,
	[Author] [varchar] (255) COLLATE Latin1_General_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblCategories] (
	[CategoryID] [int] IDENTITY (1, 1) NOT NULL ,
	[Category] [varchar] (255) COLLATE Latin1_General_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblCustomer_Order_Details] (
	[OrderDetailsID] [int] IDENTITY (1, 1) NOT NULL ,
	[OrderID] [int] NULL ,
	[OrderDetails] [varchar] (50) COLLATE Latin1_General_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblCustomer_Orders] (
	[OrderID] [int] IDENTITY (1, 1) NOT NULL ,
	[CustomerID] [int] NULL ,
	[OrderInformation] [varchar] (50) COLLATE Latin1_General_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblCustomers] (
	[CustomerID] [int] IDENTITY (1, 1) NOT NULL ,
	[CustomerName] [char] (100) COLLATE Latin1_General_CI_AS NULL ,
	[PostalAddress] [char] (255) COLLATE Latin1_General_CI_AS NULL ,
	[Postcode] [char] (10) COLLATE Latin1_General_CI_AS NULL ,
	[Country] [char] (50) COLLATE Latin1_General_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblQuotes] (
	[ID] [int] IDENTITY (1, 1) NOT NULL ,
	[CategoryID] [int] NULL ,
	[AuthorID] [int] NULL ,
	[Quote] [text] COLLATE Latin1_General_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[tblAdmin] ADD 
	CONSTRAINT [DF_tblAdmin_Included] DEFAULT (1) FOR [Included],
	CONSTRAINT [PK_tblAdmin] PRIMARY KEY  CLUSTERED 
	(
		[ID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[tblAuthors] ADD 
	CONSTRAINT [PK_tblAuthors] PRIMARY KEY  CLUSTERED 
	(
		[AuthorID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[tblCategories] ADD 
	CONSTRAINT [PK_tblCategories] PRIMARY KEY  CLUSTERED 
	(
		[CategoryID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[tblCustomer_Order_Details] ADD 
	CONSTRAINT [PK_tblCustomer_Order_Details] PRIMARY KEY  CLUSTERED 
	(
		[OrderDetailsID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[tblCustomer_Orders] ADD 
	CONSTRAINT [PK_tblCustomer_Orders] PRIMARY KEY  CLUSTERED 
	(
		[OrderID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[tblCustomers] ADD 
	CONSTRAINT [PK_tblCustomers] PRIMARY KEY  CLUSTERED 
	(
		[CustomerID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[tblQuotes] ADD 
	CONSTRAINT [PK_tblQuotes] PRIMARY KEY  CLUSTERED 
	(
		[ID]
	)  ON [PRIMARY] 
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[tblAdmin]  TO [public]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[tblAuthors]  TO [public]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[tblCategories]  TO [public]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[tblCustomer_Order_Details]  TO [public]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[tblCustomer_Orders]  TO [public]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[tblCustomers]  TO [public]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[tblQuotes]  TO [public]
GO

ALTER TABLE [dbo].[tblCustomer_Order_Details] ADD 
	CONSTRAINT [FK_tblCustomer_Order_Details_tblCustomer_Orders] FOREIGN KEY 
	(
		[OrderID]
	) REFERENCES [dbo].[tblCustomer_Orders] (
		[OrderID]
	) ON DELETE CASCADE  NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[tblCustomer_Orders] ADD 
	CONSTRAINT [FK_tblCustomer_Orders_tblCustomers] FOREIGN KEY 
	(
		[CustomerID]
	) REFERENCES [dbo].[tblCustomers] (
		[CustomerID]
	) ON DELETE CASCADE  NOT FOR REPLICATION 
GO







/*
VIEWS
*/


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[viewQuotes]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[viewQuotes]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE VIEW dbo.viewQuotes
AS
SELECT     dbo.tblQuotes.ID, dbo.tblQuotes.Quote, dbo.tblAuthors.Author, dbo.tblCategories.Category
FROM         dbo.tblAuthors INNER JOIN
                      dbo.tblQuotes ON dbo.tblAuthors.AuthorID = dbo.tblQuotes.AuthorID INNER JOIN
                      dbo.tblCategories ON dbo.tblQuotes.CategoryID = dbo.tblCategories.CategoryID

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  SELECT  ON [dbo].[viewQuotes]  TO [public]
GO













/*
The following scripts will insert data into Authors, Categories and Quotes tables


Authors
*/
INSERT INTO dbo.tblAuthors (Author)
VALUES ('Isaac Asimov')
INSERT INTO dbo.tblAuthors (Author)
VALUES ('Peter F. Drucker')
INSERT INTO dbo.tblAuthors (Author)
VALUES ('Louis Gerstner')
INSERT INTO dbo.tblAuthors (Author)
VALUES ('Sydney J. Harris')
INSERT INTO dbo.tblAuthors (Author)
VALUES ('Doug Larson')
INSERT INTO dbo.tblAuthors (Author)
VALUES ('Walter F. Mondale')
INSERT INTO dbo.tblAuthors (Author)
VALUES ('Walter Mossberg')
INSERT INTO dbo.tblAuthors (Author)
VALUES ('Nicholas Negroponte')
INSERT INTO dbo.tblAuthors (Author)
VALUES ('Robert Orben')
INSERT INTO dbo.tblAuthors (Author)
VALUES ('Pablo Picasso')
INSERT INTO dbo.tblAuthors (Author)
VALUES ('Douglas Adams')
INSERT INTO dbo.tblAuthors (Author)
VALUES ('Mark Twain')
INSERT INTO dbo.tblAuthors (Author)
VALUES ('Archimedes')
INSERT INTO dbo.tblAuthors (Author)
VALUES ('Mary Kay Ash')
INSERT INTO dbo.tblAuthors (Author)
VALUES ('Marcus Aurelius')
INSERT INTO dbo.tblAuthors (Author)
VALUES ('Wernher Von Braun')
INSERT INTO dbo.tblAuthors (Author)
VALUES ('Marie Curie')
INSERT INTO dbo.tblAuthors (Author)
VALUES ('Dave Barry')
INSERT INTO dbo.tblAuthors (Author)
VALUES ('Albert Einstein')
INSERT INTO dbo.tblAuthors (Author)
VALUES ('Benjamin Disraeli')
GO

/*
Categories
*/
INSERT INTO dbo.tblCategories (Category)
VALUES ('Computers')
INSERT INTO dbo.tblCategories (Category)
VALUES ('Experience')
INSERT INTO dbo.tblCategories (Category)
VALUES ('Science')
INSERT INTO dbo.tblCategories (Category)
VALUES ('Technology')
INSERT INTO dbo.tblCategories (Category)
VALUES ('Success')
GO

/*
Quotes
*/
INSERT INTO dbo.tblQuotes (CategoryID, AuthorID, Quote)
VALUES (1,1,'I do not fear computers. I fear the lack of them.')
INSERT INTO dbo.tblQuotes (CategoryID, AuthorID, Quote)
VALUES (1,2,'The computer is a moron.')
INSERT INTO dbo.tblQuotes (CategoryID, AuthorID, Quote)
VALUES (1,3,'Computers are magnificent tools for the realization of our dreams, but no machine can replace the human spark of spirit, compassion, love, and understanding.')
INSERT INTO dbo.tblQuotes (CategoryID, AuthorID, Quote)
VALUES (1,4,'The real danger is not that computers will begin to think like men, but that men will begin to think like computers.')
INSERT INTO dbo.tblQuotes (CategoryID, AuthorID, Quote)
VALUES (1,5,'Home computers are being called upon to perform many new functions, including the consumption of homework formerly eaten by the dog.')
INSERT INTO dbo.tblQuotes (CategoryID, AuthorID, Quote)
VALUES (1,6,'What do we want our kids to do? Sweep up around Japanese computers?')
INSERT INTO dbo.tblQuotes (CategoryID, AuthorID, Quote)
VALUES (1,7,'Why shouldn''t a PC work like a refrigerator or a toaster?')
INSERT INTO dbo.tblQuotes (CategoryID, AuthorID, Quote)
VALUES (1,8,'Computing is not about computers any more. It is about living.')
INSERT INTO dbo.tblQuotes (CategoryID, AuthorID, Quote)
VALUES (1,9,'To err is human - and to blame it on a computer is even more so.')
INSERT INTO dbo.tblQuotes (CategoryID, AuthorID, Quote)
VALUES (1,10,'Computers are useless. They can only give you answers.')
INSERT INTO dbo.tblQuotes (CategoryID, AuthorID, Quote)
VALUES (2,11,'Human beings, who are almost unique in having the ability to learn from the experience of others, are also remarkable for their apparent disinclination to do so.')
INSERT INTO dbo.tblQuotes (CategoryID, AuthorID, Quote)
VALUES (2,12,'A man who carries a cat by the tail learns something he can learn in no other way.')
INSERT INTO dbo.tblQuotes (CategoryID, AuthorID, Quote)
VALUES (3,13,'Give me a lever long enough and a fulcrum on which to place it, and I shall move the world.')
INSERT INTO dbo.tblQuotes (CategoryID, AuthorID, Quote)
VALUES (3,14,'Aerodynamically, the bumble bee shouldn''t be able to fly, but the bumble bee doesn''t know it so it goes on flying anyway.')
INSERT INTO dbo.tblQuotes (CategoryID, AuthorID, Quote)
VALUES (3,1,'There is a single light of science, and to brighten it anywhere is to brighten it everywhere.')
INSERT INTO dbo.tblQuotes (CategoryID, AuthorID, Quote)
VALUES (3,15,'Nothing has such power to broaden the mind as the ability to investigate systematically and truly all that comes under thy observation in life.')
INSERT INTO dbo.tblQuotes (CategoryID, AuthorID, Quote)
VALUES (3,16,'Our sun is one of 100 billion stars in our galaxy. Our galaxy is one of billions of galaxies populating the universe. It would be the height of presumption to think that we are the only living things in that enormous immensity.')
INSERT INTO dbo.tblQuotes (CategoryID, AuthorID, Quote)
VALUES (3,16,'We can lick gravity, but sometimes the paperwork is overwhelming.')
INSERT INTO dbo.tblQuotes (CategoryID, AuthorID, Quote)
VALUES (3,17,'Nothing in life is to be feared. It is only to be understood.')
INSERT INTO dbo.tblQuotes (CategoryID, AuthorID, Quote)
VALUES (4,18,'The Internet is the most important single development in the history of human communication since the invention of call waiting.')
INSERT INTO dbo.tblQuotes (CategoryID, AuthorID, Quote)
VALUES (4,19,'It has become appallingly obvious that our technology has exceeded our humanity.')
INSERT INTO dbo.tblQuotes (CategoryID, AuthorID, Quote)
VALUES (5,20,'One secret of success in life is for a man to be ready for his opportunity when it comes.')
GO
